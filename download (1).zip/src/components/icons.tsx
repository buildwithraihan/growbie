
import type { SVGProps } from 'react';

export function BeeIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M14 6s-1-2-2-2-2 2-2 2" />
      <path d="M14 10s-1-2-2-2-2 2-2 2" />
      <path d="M12 20a4 4 0 0 0 4-4 4 4 0 0 0-4-4H8a4 4 0 0 0-4 4 4 4 0 0 0 4 4Z" />
      <path d="M18 10h2" />
      <path d="M6 10H4" />
      <path d="M12 2v2" />
      <path d="m19.07 4.93-1.41 1.41" />
      <path d="m4.93 4.93 1.41 1.41" />
    </svg>
  );
}

export function Hexagon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
    </svg>
  );
}

export function Logo(props: SVGProps<SVGSVGElement>) {
    return (
      <div className="flex items-center justify-center" {...props}>
        <div className="bg-primary p-2 rounded-lg flex items-center justify-center">
          <BeeIcon className="text-primary-foreground h-6 w-6" />
        </div>
      </div>
    );
  }
