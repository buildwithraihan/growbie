'use client';
import * as React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { identifyStudentsFromPhoto } from '@/lib/actions';
import { Camera, Users, Upload, Loader2 } from 'lucide-react';
import Image from 'next/image';

interface FaceScannerProps {
  isOpen: boolean;
  onOpenChange: (isOpen: boolean) => void;
}

const knownStudentNames = ['Alex Bee', 'Bella Hive', 'Charlie Pollen', 'Diana Nectar', 'Evan Stinger'];

export default function FaceScanner({ isOpen, onOpenChange }: FaceScannerProps) {
  const { toast } = useToast();
  const [selectedFile, setSelectedFile] = React.useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = React.useState<string | null>(null);
  const [isLoading, setIsLoading] = React.useState(false);
  const [identifiedStudents, setIdentifiedStudents] = React.useState<string[]>([]);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
      setIdentifiedStudents([]);
    }
  };

  const handleScan = async () => {
    if (!selectedFile) {
      toast({
        variant: 'destructive',
        title: 'No file selected',
        description: 'Please select an image to scan.',
      });
      return;
    }
    
    if (!previewUrl) return;

    setIsLoading(true);
    setIdentifiedStudents([]);

    try {
      const result = await identifyStudentsFromPhoto({
        photoDataUri: previewUrl,
        knownStudentNames,
      });

      if (result.identifiedStudents) {
        setIdentifiedStudents(result.identifiedStudents);
        toast({
          title: 'Scan complete!',
          description: `${result.identifiedStudents.length} students identified.`,
        });
      }
    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Scan failed',
        description: 'Could not identify students from the image.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const resetState = () => {
    setSelectedFile(null);
    setPreviewUrl(null);
    setIdentifiedStudents([]);
    setIsLoading(false);
    onOpenChange(false);
  }

  return (
    <Dialog open={isOpen} onOpenChange={resetState}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="font-headline flex items-center gap-2"><Camera /> Face Scanner Attendance</DialogTitle>
          <DialogDescription>
            Upload a photo of your class to automatically mark attendance.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="space-y-2">
            {!previewUrl && (
              <div 
                className="flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer hover:bg-muted"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-8 h-8 text-muted-foreground mb-2"/>
                <p className="text-sm text-muted-foreground">Click to upload an image</p>
                <Input ref={fileInputRef} id="picture" type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
              </div>
            )}
            {previewUrl && (
              <div className="relative w-full h-48 rounded-lg overflow-hidden">
                <Image src={previewUrl} alt="Class preview" layout="fill" objectFit="contain" data-ai-hint="classroom students"/>
              </div>
            )}
          </div>
          {identifiedStudents.length > 0 && (
             <div className="space-y-2">
                <h3 className="font-semibold flex items-center gap-2"><Users className="w-4 h-4" /> Identified Students:</h3>
                <div className="flex flex-wrap gap-2">
                    {identifiedStudents.map(name => <span key={name} className="px-3 py-1 bg-secondary rounded-full text-sm">{name}</span>)}
                </div>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={resetState}>Cancel</Button>
          <Button onClick={handleScan} disabled={!selectedFile || isLoading}>
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Scan Photo
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
