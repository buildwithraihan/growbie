'use client';
import * as React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { User, Message } from './data';
import { MoreVertical, Phone, Video } from 'lucide-react';

interface ChatMessagesProps {
    user: User;
    messages: Message[];
    currentUserId: string;
}

export default function ChatMessages({ user, messages, currentUserId }: ChatMessagesProps) {
    const messagesEndRef = React.useRef<HTMLDivElement>(null);

    React.useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    return (
        <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b">
                <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                        <AvatarImage src={user.avatar} alt={user.name} data-ai-hint="user avatar"/>
                        <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                        <div className="font-semibold">{user.name}</div>
                        <div className="text-xs text-muted-foreground">Online</div>
                    </div>
                </div>
                <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon">
                        <Phone />
                        <span className="sr-only">Call</span>
                    </Button>
                    <Button variant="ghost" size="icon">
                        <Video />
                        <span className="sr-only">Video Call</span>
                    </Button>
                    <Button variant="ghost" size="icon">
                        <MoreVertical />
                        <span className="sr-only">More</span>
                    </Button>
                </div>
            </div>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map(message => (
                    <div
                        key={message.id}
                        className={cn(
                            "flex items-end gap-2",
                            message.senderId !== currentUserId ? 'justify-start' : 'justify-end'
                        )}
                    >
                         {message.senderId !== currentUserId && (
                             <Avatar className="h-8 w-8">
                                <AvatarImage src={user.avatar} alt={user.name} />
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                             </Avatar>
                         )}
                        <div
                            className={cn(
                                "max-w-xs md:max-w-md lg:max-w-lg p-3 rounded-lg",
                                message.senderId !== currentUserId
                                    ? 'bg-muted text-foreground'
                                    : 'bg-primary text-primary-foreground'
                            )}
                        >
                            <p>{message.text}</p>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </div>
        </div>
    );
}
