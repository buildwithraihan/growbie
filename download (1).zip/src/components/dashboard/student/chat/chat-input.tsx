'use client';
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Smile, Paperclip } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Message } from './data';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';

interface ChatInputProps {
    className?: string;
    onSendMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
    currentUserId: string;
    selectedUserId: string;
}

const emojis = ['😀', '😂', '😍', '👍', '❤️', '🎉', '🤔', '😢'];

export default function ChatInput({ className, onSendMessage, currentUserId, selectedUserId }: ChatInputProps) {
    const [message, setMessage] = React.useState('');

    const handleSend = () => {
        if (message.trim()) {
            onSendMessage({
                senderId: currentUserId,
                receiverId: selectedUserId,
                text: message,
            });
            setMessage('');
        }
    }

    const handleEmojiSelect = (emoji: string) => {
        setMessage(prev => prev + emoji);
    }

    return (
        <div className={cn("flex items-center gap-2 p-4 border-t", className)}>
            <Popover>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="icon">
                        <Smile />
                        <span className="sr-only">Emoji</span>
                    </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-2">
                    <div className="grid grid-cols-4 gap-2">
                        {emojis.map(emoji => (
                            <Button
                                key={emoji}
                                variant="ghost"
                                size="icon"
                                className="text-2xl"
                                onClick={() => handleEmojiSelect(emoji)}
                            >
                                {emoji}
                            </Button>
                        ))}
                    </div>
                </PopoverContent>
            </Popover>

            <Button variant="ghost" size="icon">
                <Paperclip />
                <span className="sr-only">Attach</span>
            </Button>
            <Input 
                placeholder="Type a message..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            />
            <Button size="icon" onClick={handleSend} disabled={!message.trim()}>
                <Send />
                <span className="sr-only">Send</span>
            </Button>
        </div>
    );
}
