'use client';
import * as React from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { User } from './data';
import { Search } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface ChatListProps {
    users: User[];
    selectedUser: User;
    onSelectUser: (user: User) => void;
    isCollapsed: boolean;
}

export default function ChatList({ users, selectedUser, onSelectUser, isCollapsed }: ChatListProps) {
    const [search, setSearch] = React.useState('');

    const filteredUsers = users.filter(user => user.name.toLowerCase().includes(search.toLowerCase()));

    return (
        <div className="flex flex-col h-full">
            <div className={cn("p-4", isCollapsed && 'p-2')}>
                <div className="relative">
                    <Search className={cn("absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground", isCollapsed && 'hidden')} />
                    <Input 
                        placeholder="Search chats..."
                        className={cn("pl-8", isCollapsed && 'hidden')}
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>
            <div className="flex-1 overflow-y-auto">
                <nav className="grid gap-1 px-2">
                    {filteredUsers.map(user => (
                        <button
                            key={user.id}
                            onClick={() => onSelectUser(user)}
                            className={cn(
                                "flex items-center gap-3 rounded-lg px-3 py-2 text-muted-foreground transition-all hover:bg-accent hover:text-accent-foreground",
                                selectedUser.id === user.id && "bg-accent text-accent-foreground",
                                isCollapsed && "justify-center"
                            )}
                        >
                            <Avatar className="h-9 w-9">
                                <AvatarImage src={user.avatar} alt={user.name} data-ai-hint="user avatar"/>
                                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <div className={cn("flex-1 text-left", isCollapsed && "hidden")}>
                                <div className="font-medium">{user.name}</div>
                                <p className="text-xs text-muted-foreground truncate">{user.lastMessage}</p>
                            </div>
                            <div className={cn("text-xs text-muted-foreground", isCollapsed && "hidden")}>
                                {user.lastMessageTime}
                            </div>
                        </button>
                    ))}
                </nav>
            </div>
        </div>
    )
}
