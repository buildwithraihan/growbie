export interface User {
    id: string;
    name: string;
    avatar: string;
    lastMessage: string;
    lastMessageTime: string;
}

export interface Message {
    id: string;
    senderId: string;
    receiverId: string;
    text: string;
    timestamp: string;
}

export const mockUsers: User[] = [
    {
        id: 'user-2',
        name: 'Bella Hive',
        avatar: 'https://picsum.photos/100/102',
        lastMessage: 'Sure, I can help with that!',
        lastMessageTime: '10:42 AM'
    },
    {
        id: 'user-3',
        name: 'Charlie Pollen',
        avatar: 'https://picsum.photos/100/103',
        lastMessage: 'See you in class tomorrow.',
        lastMessageTime: '9:30 AM'
    },
    {
        id: 'user-4',
        name: 'Diana Nectar',
        avatar: 'https://picsum.photos/100/104',
        lastMessage: 'Did you finish the assignment?',
        lastMessageTime: 'Yesterday'
    },
    {
        id: 'user-5',
        name: 'Evan Stinger',
        avatar: 'https://picsum.photos/100/105',
        lastMessage: '👍',
        lastMessageTime: '2 days ago'
    },
];


export const mockMessages: Message[] = [
    { id: 'msg-1', senderId: 'user-2', receiverId: 'student-123', text: 'Hey! Are you free to study for the bio exam?', timestamp: '10:30 AM' },
    { id: 'msg-2', senderId: 'student-123', receiverId: 'user-2', text: 'Hey Bella! Yeah, I am. When and where?', timestamp: '10:31 AM' },
    { id: 'msg-3', senderId: 'user-2', receiverId: 'student-123', text: 'Library in 20 minutes?', timestamp: '10:32 AM' },
    { id: 'msg-4', senderId: 'student-123', receiverId: 'user-2', text: 'Perfect! Also, can you help me with the photosynthesis part?', timestamp: '10:33 AM' },
    { id: 'msg-5', senderId: 'user-2', receiverId: 'student-123', text: 'Sure, I can help with that!', timestamp: '10:42 AM' },
    // Other chats
    { id: 'msg-6', senderId: 'user-3', receiverId: 'student-123', text: 'See you in class tomorrow.', timestamp: '9:30 AM' },
    { id: 'msg-7', senderId: 'user-4', receiverId: 'student-123', text: 'Did you finish the assignment?', timestamp: 'Yesterday' },
    { id: 'msg-8', senderId: 'user-5', receiverId: 'student-123', text: '👍', timestamp: '2 days ago' },
];
