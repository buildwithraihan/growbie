'use client';
import * as React from 'react';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { User, Message } from './data';
import ChatMessages from './chat-messages';
import ChatList from './chat-list';
import ChatInput from './chat-input';

interface ChatLayoutProps {
    defaultLayout?: number[];
    defaultCollapsed?: boolean;
    navCollapsedSize: number;
    users: User[];
    messages: Message[];
    currentUserId: string;
    onSendMessage: (message: Omit<Message, 'id' | 'timestamp'>) => void;
}

export default function ChatLayout({
    defaultLayout = [320, 1080],
    defaultCollapsed = false,
    navCollapsedSize,
    users,
    messages,
    currentUserId,
    onSendMessage
}: ChatLayoutProps) {
    const [isCollapsed, setIsCollapsed] = React.useState(defaultCollapsed);
    const [selectedUser, setSelectedUser] = React.useState<User>(users[0]);
    
    return (
        <ResizablePanelGroup
            direction="horizontal"
            onLayout={(sizes: number[]) => {
                document.cookie = `react-resizable-panels:layout=${JSON.stringify(sizes)}`;
            }}
            className="h-full max-h-full items-stretch"
        >
            <ResizablePanel
                defaultSize={defaultLayout[0]}
                collapsedSize={navCollapsedSize}
                collapsible={true}
                minSize={24}
                maxSize={30}
                onCollapse={() => {
                    setIsCollapsed(true);
                    document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(true)}`;
                }}
                onExpand={() => {
                    setIsCollapsed(false);
                    document.cookie = `react-resizable-panels:collapsed=${JSON.stringify(false)}`;
                }}
                className={cn(isCollapsed && 'min-w-[50px] transition-all duration-300 ease-in-out', 'flex flex-col bg-card border rounded-lg')}
            >
                <ChatList 
                    users={users} 
                    selectedUser={selectedUser} 
                    onSelectUser={setSelectedUser}
                    isCollapsed={isCollapsed}
                />
            </ResizablePanel>
            <ResizableHandle withHandle />
            <ResizablePanel defaultSize={defaultLayout[1]} minSize={30}>
                <div className="flex flex-col h-full bg-card border rounded-lg">
                    <ChatMessages 
                        user={selectedUser} 
                        messages={messages.filter(m => m.senderId === selectedUser.id || m.receiverId === selectedUser.id)}
                        currentUserId={currentUserId}
                    />
                    <ChatInput 
                        onSendMessage={onSendMessage}
                        currentUserId={currentUserId}
                        selectedUserId={selectedUser.id}
                    />
                </div>
            </ResizablePanel>
        </ResizablePanelGroup>
    );
}
