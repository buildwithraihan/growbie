'use client';

import * as React from 'react';
import { BeeIcon } from '@/components/icons';

const GAME_WIDTH = 500;
const GAME_HEIGHT = 500;
const BEE_SIZE = 30;
const GRAVITY = 0.5;
const FLAP_STRENGTH = -8;
const OBSTACLE_WIDTH = 60;
const OBSTACLE_GAP = 150;
const OBSTACLE_SPEED = 2.5;
const OBSTACLE_INTERVAL = 120; // in frames

interface FlappyBeeGameProps {
  onGameOver: (score: number) => void;
}

export default function FlappyBeeGame({ onGameOver }: FlappyBeeGameProps) {
  const gameContainerRef = React.useRef<HTMLDivElement>(null);
  const gameLoopRef = React.useRef<number>();
  const frameCountRef = React.useRef(0);

  const [beePosition, setBeePosition] = React.useState(GAME_HEIGHT / 2);
  const [beeVelocity, setBeeVelocity] = React.useState(0);
  const [obstacles, setObstacles] = React.useState<{ x: number; gapY: number; passed: boolean }[]>([]);
  const [score, setScore] = React.useState(0);
  const [isGameOver, setIsGameOver] = React.useState(false);

  const flap = React.useCallback(() => {
    if (!isGameOver) {
      setBeeVelocity(FLAP_STRENGTH);
    }
  }, [isGameOver]);

  React.useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        flap();
      }
    };
    const handleClick = () => {
        flap();
    };

    window.addEventListener('keydown', handleKeyPress);
    const gameContainer = gameContainerRef.current;
    gameContainer?.addEventListener('click', handleClick);

    return () => {
      window.removeEventListener('keydown', handleKeyPress);
      gameContainer?.removeEventListener('click', handleClick);
    };
  }, [flap]);

  const gameLoop = React.useCallback(() => {
    if (isGameOver) {
        cancelAnimationFrame(gameLoopRef.current!);
        return;
    }
    // Bee physics
    setBeeVelocity(v => v + GRAVITY);
    setBeePosition(p => p + beeVelocity);

    // Obstacle logic
    frameCountRef.current += 1;
    if (frameCountRef.current % OBSTACLE_INTERVAL === 0) {
      const gapY = Math.random() * (GAME_HEIGHT - OBSTACLE_GAP - 100) + 50;
      setObstacles(o => [...o, { x: GAME_WIDTH, gapY, passed: false }]);
    }

    // Move obstacles and update score
    setObstacles(currentObstacles => 
        currentObstacles
        .map(obs => ({ ...obs, x: obs.x - OBSTACLE_SPEED }))
        .filter(obs => obs.x > -OBSTACLE_WIDTH)
    );
    
    setObstacles(currentObstacles => {
      let newScore = score;
      const updatedObstacles = currentObstacles.map(obs => {
        if (!obs.passed && obs.x + OBSTACLE_WIDTH < GAME_WIDTH / 2 - BEE_SIZE / 2) {
          newScore++;
          return { ...obs, passed: true };
        }
        return obs;
      });
      if (newScore > score) {
        setScore(newScore);
      }
      return updatedObstacles;
    });


    // Collision detection
    // Ground collision
    if (beePosition > GAME_HEIGHT - BEE_SIZE || beePosition < 0) {
      setIsGameOver(true);
      onGameOver(score);
      return;
    }
    // Obstacle collision
    for (const obs of obstacles) {
      const beeX = GAME_WIDTH / 2 - BEE_SIZE / 2;
      if (
        beeX < obs.x + OBSTACLE_WIDTH &&
        beeX + BEE_SIZE > obs.x &&
        (beePosition < obs.gapY || beePosition + BEE_SIZE > obs.gapY + OBSTACLE_GAP)
      ) {
        setIsGameOver(true);
        onGameOver(score);
        return;
      }
    }

    gameLoopRef.current = requestAnimationFrame(gameLoop);
  }, [beePosition, beeVelocity, obstacles, onGameOver, score, isGameOver]);

  React.useEffect(() => {
    gameLoopRef.current = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(gameLoopRef.current!);
  }, [gameLoop]);

  return (
    <div ref={gameContainerRef} className="w-full h-full bg-blue-200 relative overflow-hidden cursor-pointer">
      {/* Bee */}
      <div style={{ top: beePosition, left: 'calc(50% - 15px)' }} className="absolute transition-transform duration-100 ease-linear">
          <BeeIcon className="w-8 h-8 text-yellow-500 -rotate-12" style={{ transform: `rotate(${Math.min(Math.max(beeVelocity * 4, -30), 30)}deg)`}}/>
      </div>

      {/* Obstacles */}
      {obstacles.map((obs, i) => (
        <React.Fragment key={i}>
          {/* Top Obstacle */}
          <div
            style={{
              left: obs.x,
              top: 0,
              height: obs.gapY,
              width: OBSTACLE_WIDTH,
            }}
            className="absolute bg-green-600 border-2 border-green-800"
          >
            <div className="w-full h-full bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')] opacity-20"></div>
          </div>
          {/* Bottom Obstacle */}
          <div
            style={{
              left: obs.x,
              top: obs.gapY + OBSTACLE_GAP,
              height: GAME_HEIGHT - obs.gapY - OBSTACLE_GAP,
              width: OBSTACLE_WIDTH,
            }}
            className="absolute bg-green-600 border-2 border-green-800"
          >
             <div className="w-full h-full bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')] opacity-20"></div>
          </div>
        </React.Fragment>
      ))}

      {/* Score */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-white text-4xl font-bold font-headline" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
        {score}
      </div>
    </div>
  );
}
