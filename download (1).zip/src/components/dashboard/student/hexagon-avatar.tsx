import * as React from 'react';
import { cn } from '@/lib/utils';
import { Avatar } from '@/components/ui/avatar';

interface HexagonAvatarProps extends React.ComponentProps<typeof Avatar> {}

export function HexagonAvatar({ className, children, ...props }: HexagonAvatarProps) {
  const hexagonClipPath =
    'polygon(50% 0, 93% 25%, 93% 75%, 50% 100%, 7% 75%, 7% 25%)';

  return (
    <div
      className={cn('relative h-10 w-10', className)}
      style={{ clipPath: hexagonClipPath }}
      {...props}
    >
      <Avatar
        className="h-full w-full rounded-none"
      >
        {children}
      </Avatar>
    </div>
  );
}
