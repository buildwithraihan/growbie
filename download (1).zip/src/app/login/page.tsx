import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { BeeIcon } from '@/components/icons';
import { BookUser, User } from 'lucide-react';

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-4">
      <Card className="w-full max-w-sm">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4 items-center gap-2">
            <div className='bg-primary p-3 rounded-2xl'>
                <BeeIcon className="h-8 w-8 text-primary-foreground"/>
            </div>
            <h1 className='font-headline text-4xl'>Growbie</h1>
          </div>
          <CardTitle className="font-headline text-3xl">Welcome Back!</CardTitle>
          <CardDescription>Select your role to sign in.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4">
          <Button asChild size="lg" className="w-full">
            <Link href="/student">
              <User className="mr-2 h-5 w-5" />
              Sign in as a Student
            </Link>
          </Button>
          <Button asChild size="lg" variant="secondary" className="w-full">
            <Link href="/teacher">
              <BookUser className="mr-2 h-5 w-5" />
              Sign in as a Teacher
            </Link>
          </Button>
        </CardContent>
        <CardFooter className="text-center text-xs text-muted-foreground">
          <p>Let's grow together!</p>
        </CardFooter>
      </Card>
    </div>
  );
}
