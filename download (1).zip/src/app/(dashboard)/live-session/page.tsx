'use client';
import * as React from 'react';
import Image from 'next/image';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CheckCircle, Clock, UserCheck } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import FaceScanner from '@/components/dashboard/teacher/face-scanner';

const joinedStudents = [
  { id: 1, name: 'Alex Bee', avatar: '101', status: 'Joined', time: '9:01 AM', anomalous: false },
  { id: 3, name: 'Charlie Pollen', avatar: '103', status: 'Joined', time: '9:02 AM', anomalous: false },
  { id: 5, name: 'Evan Stinger', avatar: '105', status: 'Joined on time', time: '9:00 AM', anomalous: true },
];

export default function LiveSessionPage() {
  const [isScannerOpen, setIsScannerOpen] = React.useState(false);
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <div className="md:col-span-2">
        <Card>
          <CardHeader>
            <CardTitle className="font-headline">Live Session: Biology 101</CardTitle>
            <CardDescription>
              Students who have joined the session will appear here. The session is active for the next 10 minutes.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Join Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {joinedStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="hidden h-9 w-9 sm:flex">
                          <AvatarImage src={`https://picsum.photos/100/${student.avatar}`} data-ai-hint="student avatar" alt="Avatar" />
                          <AvatarFallback>
                            {student.name.split(' ').map((n) => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="font-medium">{student.name}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={student.anomalous ? 'destructive' : 'default'} className="bg-green-600 hover:bg-green-700">
                        <CheckCircle className="mr-2 h-4 w-4" />
                        {student.status}
                      </Badge>
                      {student.anomalous && (
                         <Badge variant="destructive" className="ml-2">Anomalous</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center text-muted-foreground">
                        <Clock className="mr-2 h-4 w-4" />
                        {student.time}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
      <div>
        <Card className="mb-4">
          <CardHeader>
            <CardTitle className="font-headline">Join Session</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center text-center">
            <p className="text-muted-foreground mb-4">
              Students can scan this QR code to join the session.
            </p>
            <div className="p-4 bg-white rounded-lg">
              <Image
                src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=https://example.com/join/b101-2024-05-21"
                width={200}
                height={200}
                alt="QR Code for session"
                data-ai-hint="qr code"
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
                Session ID: b101-2024-05-21
            </p>
          </CardContent>
        </Card>
        <Card>
            <CardHeader>
                <CardTitle className="font-headline">Face Scanner</CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-muted-foreground mb-4">
                    Use the camera to identify and mark students present.
                </p>
                <Button className="w-full" onClick={() => setIsScannerOpen(true)}>
                    <UserCheck className="mr-2 h-4 w-4"/>
                    Open Face Scanner
                </Button>
            </CardContent>
        </Card>
      </div>
      <FaceScanner isOpen={isScannerOpen} onOpenChange={setIsScannerOpen} />
    </div>
  );
}
