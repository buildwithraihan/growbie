'use client';

import * as React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Bot,
  Gauge,
  QrCode,
  School,
  Users,
  CalendarCheck,
  Lightbulb,
  Shapes,
  Medal,
  PlusCircle,
  Gamepad2,
  Newspaper,
  MessageSquare,
  Timer,
} from 'lucide-react';

import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { UserNav } from '@/components/dashboard/user-nav';
import { Logo } from '@/components/icons';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const isTeacher = pathname.startsWith('/teacher');

  const navItems = isTeacher
    ? [
        { href: '/teacher', icon: Gauge, label: 'Dashboard' },
        { href: '/live-session', icon: QrCode, label: 'Live Session' },
        { href: '/teacher/students', icon: Users, label: 'Students' },
        { href: '/teacher/award-badge', icon: Medal, label: 'Award Badge' },
        { href: '/teacher/enter-marks', icon: PlusCircle, label: 'Enter Marks'},
      ]
    : [
        { href: '/student', icon: Gauge, label: 'Dashboard' },
        { href: '/student/learning-path', icon: Lightbulb, label: 'My Learning' },
        { href: '/student/skills', icon: Shapes, label: 'My Skills' },
        { href: '/student/classes', icon: School, label: 'Classes' },
        { href: '/student/attendance', icon: CalendarCheck, label: 'Attendance' },
        { href: '/student/smart-break', icon: Gamepad2, label: 'Smart Break' },
        { href: '/student/bee-news', icon: Newspaper, label: 'Bee News' },
        { href: '/student/buzz-chat', icon: MessageSquare, label: 'Buzz Chat' },
        { href: '/student/bee-focus', icon: Timer, label: 'Bee Focus' },
      ];
  
  const role = isTeacher ? 'teacher' : 'student';

  const isLinkActive = (href: string) => {
    if (href === '/student' || href === '/teacher') {
      return pathname === href;
    }
    if (href.startsWith('/student/lesson') && pathname.startsWith('/student/lesson')) {
        return href === '/student/learning-path';
    }
    return pathname.startsWith(href);
  };

  return (
    <TooltipProvider>
      <div className="flex min-h-screen w-full flex-col bg-muted/40">
        <aside className="fixed inset-y-0 left-0 z-10 hidden w-14 flex-col border-r bg-background sm:flex">
          <nav className="flex flex-col items-center gap-4 px-2 sm:py-5">
            <Link
              href="#"
              className="group flex h-9 w-9 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-lg font-semibold text-primary-foreground md:h-8 md:w-8 md:text-base"
            >
              <Logo className="h-4 w-4" />
              <span className="sr-only">Growbie</span>
            </Link>
            {navItems.map((item) => (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>
                  <Link
                    href={item.href}
                    className={cn(
                      'flex h-9 w-9 items-center justify-center rounded-lg transition-colors md:h-8 md:w-8',
                      isLinkActive(item.href)
                        ? 'bg-accent text-accent-foreground'
                        : 'text-muted-foreground hover:text-foreground'
                    )}
                  >
                    <item.icon className="h-5 w-5" />
                    <span className="sr-only">{item.label}</span>
                  </Link>
                </TooltipTrigger>
                <TooltipContent side="right">{item.label}</TooltipContent>
              </Tooltip>
            ))}
          </nav>
        </aside>
        <div className="flex flex-col sm:gap-4 sm:py-4 sm:pl-14">
          <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
            <div className='flex-1 flex items-center gap-2'>
               <h1 className="font-headline text-xl">Growbie</h1>
            </div>
            <UserNav role={role} />
          </header>
          <main className="flex-1 items-start gap-4 p-4 sm:px-6 sm:py-0 md:gap-8">
            {children}
          </main>
        </div>
      </div>
    </TooltipProvider>
  );
}
