'use client';
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { checkAnomalousJoin } from '@/lib/actions';
import { useToast } from '@/hooks/use-toast';
import { Check, Loader2, Wifi } from 'lucide-react';
import { BeeIcon } from '@/components/icons';

export default function JoinSessionPage({ params }: { params: { id: string } }) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = React.useState(false);
  const [hasJoined, setHasJoined] = React.useState(false);

  const handleJoin = async () => {
    setIsLoading(true);

    try {
      const result = await checkAnomalousJoin({
        studentId: 'student-123',
        sessionId: params.id,
        // Mock data for demonstration purposes
        ipAddress: '203.0.113.1',
        latitude: 34.0522,
        longitude: -118.2437,
        recentIpAddresses: ['198.51.100.1', '192.0.2.1'],
        recentLocations: [{ latitude: 37.7749, longitude: -122.4194 }],
      });

      if (result.isAnomalous) {
        toast({
          variant: 'destructive',
          title: 'Anomalous Join Detected',
          description: result.reason,
        });
      } else {
        toast({
          title: 'Successfully Joined!',
          description: 'Your attendance has been recorded.',
          className: 'bg-green-600 text-white',
        });
      }
      setHasJoined(true);

    } catch (error) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not join the session.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md text-center">
        <CardHeader>
          <div className="flex justify-center mb-4 items-center gap-2">
            <div className='bg-primary p-2 rounded-lg'>
                <BeeIcon className="h-6 w-6 text-primary-foreground"/>
            </div>
            <h1 className='font-headline text-2xl'>Growbie</h1>
          </div>
          <CardTitle className="font-headline text-3xl">Join Live Session</CardTitle>
          <CardDescription>
            You are joining the session for <span className="font-bold">Biology 101</span>
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center space-y-4">
            {hasJoined ? (
                <>
                    <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
                        <Check className="w-12 h-12 text-green-600"/>
                    </div>
                    <p className="text-lg font-semibold">You're all set!</p>
                    <p className="text-muted-foreground">Your attendance has been marked.</p>
                </>
            ): (
                <>
                    <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center">
                        <Wifi className="w-12 h-12 text-primary"/>
                    </div>
                    <p className="text-muted-foreground">
                        Ready to mark your attendance?
                    </p>
                    <Button onClick={handleJoin} disabled={isLoading} size="lg" className="w-full">
                        {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Join and Mark Present
                    </Button>
                </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
