'use client';

import * as React from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  CheckCircle,
  HeartPulse,
  Code,
  Video,
  Palette,
  Briefcase,
  Cog,
  Landmark,
  BookOpen,
  Loader2,
  Shapes,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { saveUserSkills } from '@/lib/actions';

const skills = [
  { id: 'medical', name: 'Medical', icon: HeartPulse },
  { id: 'cs', name: 'Computer Science', icon: Code },
  { id: 'media', name: 'Media', icon: Video },
  { id: 'design', name: 'Design', icon: Palette },
  { id: 'business', name: 'Business', icon: Briefcase },
  { id: 'engineering', name: 'Engineering', icon: Cog },
  { id: 'arts', name: 'Arts & Culture', icon: Landmark },
  { id: 'finance', name: 'Finance & Economics', icon: BookOpen },
];

export const sampleCourses: Record<string, { name: string; description: string }[]> = {
  medical: [
    { name: 'Intro to Anatomy', description: 'Explore the human body\'s systems and structures.'},
    { name: 'Medical Terminology', description: 'Learn the essential language of healthcare professionals.'},
  ],
  cs: [
    { name: 'Python Basics', description: 'Learn the fundamentals of Python programming.' },
    { name: 'Web Development', description: 'Build your first interactive website.' },
    { name: 'AI Fundamentals', description: 'Explore the exciting world of Artificial Intelligence.' },
  ],
  media: [
      {name: 'Digital Storytelling', description: 'Craft compelling narratives using various digital formats.'},
      {name: 'Video Production Essentials', description: 'Learn the basics of shooting and editing professional videos.'},
  ],
  design: [
    { name: 'UI/UX Design Principles', description: 'Understand the core concepts of user-centric design.' },
    { name: 'Graphic Design Masterclass', description: 'Create stunning visuals with industry-standard tools.' },
  ],
  business: [
      { name: 'Introduction to Marketing', description: 'Learn how to promote and sell products effectively.' },
      { name: 'Entrepreneurship 101', description: 'Turn your business idea into a reality.' },
  ],
  engineering: [
      { name: 'Robotics Fundamentals', description: 'Build and program your first robot.'},
      { name: 'Mechanical Engineering Concepts', description: 'Discover the principles that make machines work.'}
  ],
  arts: [
      { name: 'Modern Art History', description: 'Journey through the most influential art movements.'},
      { name: 'Creative Writing Workshop', description: 'Unleash your inner author and craft compelling stories.'}
  ],
  finance: [
    { name: 'Personal Finance Management', description: 'Master budgeting, saving, and investing for your future.'},
    { name: 'Stock Market for Beginners', description: 'Understand how the stock market works and make informed decisions.'}
  ]
};


export default function SkillsSelectionPage() {
  const router = useRouter();
  const { toast } = useToast();
  const [selectedSkills, setSelectedSkills] = React.useState<string[]>([]);
  const [isLoading, setIsLoading] = React.useState(false);
  const [isInitialLoad, setIsInitialLoad] = React.useState(true);

  React.useEffect(() => {
    // In a real app, you would fetch this from your backend/database
    const savedSkills = localStorage.getItem('user_skills_ids');
    if (savedSkills) {
      setSelectedSkills(savedSkills.split(','));
    }
    setIsInitialLoad(false);
  }, []);

  const handleSkillSelect = (skillId: string) => {
    setSelectedSkills((prev) =>
      prev.includes(skillId)
        ? prev.filter((id) => id !== skillId)
        : [...prev, skillId]
    );
  };

  const handleSubmit = async () => {
      if (selectedSkills.length < 3) {
          toast({
              variant: 'destructive',
              title: "Select at least 3 skills",
              description: "Please select at least 3 skills to continue."
          });
          return;
      }
      setIsLoading(true);
      try {
          // We use localStorage for this demo app.
          localStorage.setItem('user_skills_ids', selectedSkills.join(','));
          localStorage.setItem('user_has_selected_skills', 'true');
          
          await saveUserSkills(selectedSkills);

          toast({
              title: "Skills Saved!",
              description: "Your learning experience is now personalized.",
              className: 'bg-green-600 text-white'
          })
          const queryParams = new URLSearchParams({ skills: selectedSkills.join(',') });
          router.push(`/student/learning-path?${queryParams.toString()}`);
      } catch (error) {
          console.error(error);
          toast({
              variant: 'destructive',
              title: "Uh oh!",
              description: "There was a problem saving your skills."
          })
      } finally {
          setIsLoading(false);
      }
  }
  
  const recommendedCourses = selectedSkills.flatMap(skillId => sampleCourses[skillId] || []);

  if (isInitialLoad) {
      return (
          <div className="flex h-screen items-center justify-center">
              <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
          </div>
      );
  }

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="text-center mb-8">
        <h1 className="font-headline text-4xl font-bold flex items-center justify-center gap-3">
          <Shapes className="h-10 w-10 text-primary" />
          Explore & Update Your Skills
        </h1>
        <p className="text-muted-foreground text-lg mt-2">
          Select at least 3 skills to personalize your learning experience.
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-8">
        {skills.map((skill) => {
          const isSelected = selectedSkills.includes(skill.id);
          return (
            <Card
              key={skill.id}
              className={cn(
                'cursor-pointer transition-all hover:shadow-lg hover:-translate-y-1',
                isSelected && 'ring-2 ring-primary ring-offset-2'
              )}
              onClick={() => handleSkillSelect(skill.id)}
            >
              <CardContent className="flex flex-col items-center justify-center p-6 text-center relative">
                {isSelected && (
                  <CheckCircle className="h-6 w-6 text-green-500 absolute top-2 right-2" />
                )}
                <skill.icon className="h-12 w-12 text-primary mb-4" />
                <h3 className="font-semibold text-lg">{skill.name}</h3>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {recommendedCourses.length > 0 && (
          <div className='mb-8'>
              <h2 className='font-headline text-3xl font-bold mb-4 text-center'>Recommended Courses For You</h2>
               <div className="grid gap-4 md:grid-cols-3">
                   {recommendedCourses.map(course => (
                       <Card key={course.name}>
                           <CardHeader>
                               <CardTitle>{course.name}</CardTitle>
                           </CardHeader>
                           <CardContent>
                               <p className="text-muted-foreground">{course.description}</p>
                           </CardContent>
                       </Card>
                   ))}
               </div>
          </div>
      )}

      <div className="text-center">
        <Button 
            size="lg" 
            disabled={selectedSkills.length < 3 || isLoading}
            onClick={handleSubmit}
        >
          {isLoading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Update Learning Path
        </Button>
      </div>
    </div>
  );
}
