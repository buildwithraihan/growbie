'use client';
import * as React from 'react';
import FlappyBeeGame from '@/components/dashboard/student/flappy-bee-game';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Gamepad2, Trophy } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function SmartBreakPage() {
    const [gameState, setGameState] = React.useState<'ready' | 'playing' | 'over'>('ready');
    const [score, setScore] = React.useState(0);
    const [highScore, setHighScore] = React.useState(0);

    React.useEffect(() => {
        const savedHighScore = localStorage.getItem('flappyBeeHighScore') || '0';
        setHighScore(parseInt(savedHighScore, 10));
    }, []);

    const handleGameOver = (finalScore: number) => {
        setScore(finalScore);
        setGameState('over');
        if (finalScore > highScore) {
            setHighScore(finalScore);
             if (typeof window !== 'undefined') {
                localStorage.setItem('flappyBeeHighScore', finalScore.toString());
            }
        }
    };

    const handlePlayAgain = () => {
        setScore(0);
        setGameState('playing');
    };

    return (
        <div className="container mx-auto p-4 md:p-8 flex flex-col items-center">
            <div className="mb-8 text-center">
                <h1 className="font-headline text-4xl font-bold flex items-center justify-center gap-3">
                    <Gamepad2 className="h-10 w-10 text-primary" />
                    Smart Break: Flappy Bee
                </h1>
                <p className="text-muted-foreground text-lg mt-2">
                    Take a short break and help Buzzy fly!
                </p>
            </div>
            
            <div className="w-full max-w-lg flex justify-center items-center mb-4 gap-8">
                <div className="text-center">
                    <p className="text-muted-foreground">Score</p>
                    <p className="font-bold text-4xl">{gameState === 'playing' ? '...' : score}</p>
                </div>
                 <div className="text-center">
                    <p className="text-muted-foreground">High Score</p>
                    <p className="font-bold text-4xl">{highScore}</p>
                </div>
            </div>

            <Card className="w-full max-w-lg aspect-square relative overflow-hidden">
                {gameState === 'playing' ? (
                    <FlappyBeeGame onGameOver={handleGameOver} />
                ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center bg-secondary/50 p-8 text-center">
                        {gameState === 'ready' && (
                             <>
                                <CardTitle className="font-headline text-3xl mb-4">Get Ready!</CardTitle>
                                <CardDescription className="mb-6">Click or press Spacebar to make Buzzy the Bee flap its wings. Guide it through the gaps in the branches.</CardDescription>
                                <Button size="lg" onClick={handlePlayAgain}>Start Game</Button>
                            </>
                        )}
                        {gameState === 'over' && (
                             <>
                                <CardTitle className="font-headline text-3xl mb-4">Game Over!</CardTitle>
                                {score > highScore && score > 0 ? (
                                    <div className="flex items-center gap-2 mb-4 text-primary">
                                        <Trophy className="w-6 h-6" />
                                        <p className="font-semibold">New High Score!</p>
                                    </div>
                                ) : (
                                    <CardDescription className="mb-6">Great try! Take another break whenever you need one.</CardDescription>
                                )}
                                <Button size="lg" onClick={handlePlayAgain}>Play Again</Button>
                            </>
                        )}
                    </div>
                )}
            </Card>
        </div>
    );
}
