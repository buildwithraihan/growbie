'use client';
import * as React from 'react';
import ChatLayout from '@/components/dashboard/student/chat/chat-layout';
import { mockUsers, mockMessages, Message } from '@/components/dashboard/student/chat/data';

export default function BuzzChatPage() {
  const [messages, setMessages] = React.useState(mockMessages);

  const handleSendMessage = (newMessage: Omit<Message, 'id' | 'timestamp'>) => {
    const message: Message = {
      ...newMessage,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, message]);
  };

  return (
    <div className="h-[calc(100vh-theme(spacing.24))]">
        <ChatLayout
            defaultLayout={[320, 655]}
            defaultCollapsed={false}
            navCollapsedSize={8}
            users={mockUsers}
            messages={messages}
            currentUserId="student-123"
            onSendMessage={handleSendMessage}
        />
    </div>
  );
}
