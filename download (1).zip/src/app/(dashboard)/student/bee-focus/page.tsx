
'use client';
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Timer, Play, Pause, RotateCcw, Award, BarChart3 } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const formatTime = (seconds: number) => {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
};

export default function BeeFocusPage() {
  const [sessionLength, setSessionLength] = React.useState(25 * 60);
  const [timeLeft, setTimeLeft] = React.useState(sessionLength);
  const [isActive, setIsActive] = React.useState(false);
  const [isPaused, setIsPaused] = React.useState(false);

  React.useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isActive && !isPaused) {
      interval = setInterval(() => {
        setTimeLeft((prevTime) => {
          if (prevTime <= 1) {
            clearInterval(interval!);
            setIsActive(false);
            // TODO: Add notification and award points
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else {
      if (interval) clearInterval(interval);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, isPaused]);

  React.useEffect(() => {
    setTimeLeft(sessionLength);
  }, [sessionLength]);

  const handleStart = (minutes: number) => {
    const newSessionLength = minutes * 60;
    setSessionLength(newSessionLength);
    setTimeLeft(newSessionLength);
    setIsActive(true);
    setIsPaused(false);
  };

  const handlePauseResume = () => {
    setIsPaused(!isPaused);
  };

  const handleReset = () => {
    setIsActive(false);
    setIsPaused(false);
    setTimeLeft(sessionLength);
  };

  const progress = (sessionLength - timeLeft) / sessionLength * 100;

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8 text-center">
        <h1 className="font-headline text-4xl font-bold flex items-center justify-center gap-3">
          <Timer className="h-10 w-10 text-primary" />
          Bee Focus
        </h1>
        <p className="text-muted-foreground text-lg mt-2">
          Your Pomodoro timer to stay productive.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2">
          <Card className="w-full">
            <CardHeader className="text-center">
              <CardTitle className="text-7xl font-mono">{formatTime(timeLeft)}</CardTitle>
            </CardHeader>
            <CardContent>
                <Progress value={progress} className="mb-8" />
              <div className="flex justify-center gap-4">
                {!isActive ? (
                  <div className="flex gap-2">
                    <Button onClick={() => handleStart(25)} size="lg">Start 25 min</Button>
                    <Button onClick={() => handleStart(50)} size="lg" variant="secondary">Start 50 min</Button>
                  </div>
                ) : (
                  <div className="flex gap-4">
                    <Button onClick={handlePauseResume} size="lg">
                      {isPaused ? <Play /> : <Pause />}
                      <span className="ml-2">{isPaused ? 'Resume' : 'Pause'}</span>
                    </Button>
                    <Button onClick={handleReset} size="lg" variant="outline">
                        <RotateCcw />
                        <span className="ml-2">Reset</span>
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2">
                <BarChart3 />
                Focus Stats
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="today">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="today">Today</TabsTrigger>
                  <TabsTrigger value="week">This Week</TabsTrigger>
                </TabsList>
                <TabsContent value="today" className="mt-4">
                  <div className="space-y-4">
                     <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Focus Sessions</span>
                        <span className="font-bold">2</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Total Time</span>
                        <span className="font-bold">50 mins</span>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="week" className="mt-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Focus Sessions</span>
                        <span className="font-bold">14</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Total Time</span>
                        <span className="font-bold">7 hours</span>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          <Card className="mt-4">
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2">
                <Award />
                Honey Points
              </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-center text-4xl font-bold">
                    1,250 🍯
                </p>
                <p className="text-center text-sm text-muted-foreground mt-2">
                    +10 points for each completed 25 min session!
                </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
