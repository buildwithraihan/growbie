'use client';
import * as React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Newspaper, Link as LinkIcon } from 'lucide-react';
import { useRouter } from 'next/navigation';

const skillsMap: Record<string, string> = {
    medical: 'Medical',
    cs: 'Computer Science',
    media: 'Media',
    design: 'Design',
    business: 'Business',
    engineering: 'Engineering',
    arts: 'Arts & Culture',
    finance: 'Finance & Economics',
};

const mockNews: Record<string, any[]> = {
  cs: [
    {
      title: 'New AI Model Released by Google',
      description: 'Google has announced the release of its latest AI model, which promises to revolutionize natural language processing.',
      source: 'https://blog.google/technology/ai/',
      date: '2024-05-22',
    },
    {
      title: 'The Rise of Quantum Computing',
      description: 'Quantum computers are becoming more powerful, with potential impacts on cryptography and scientific research.',
      source: '#',
      date: '2024-05-21',
    },
    {
        title: '5G and its impact on IoT',
        description: 'With the rollout of 5G networks, the Internet of Things is poised for massive growth.',
        source: '#',
        date: '2024-05-20',
    }
  ],
  medical: [
    {
      title: 'Breakthrough in Cancer Research',
      description: 'A new study has identified a promising new drug for treating several types of cancer.',
      source: '#',
      date: '2024-05-22',
    },
    {
      title: 'The Importance of Mental Health in a Post-Pandemic World',
      description: 'Experts are emphasizing the need for greater awareness and resources for mental health.',
      source: '#',
      date: '2024-05-20',
    },
  ],
  business: [
    {
        title: 'Global Markets React to New Policies',
        description: 'Recent economic policies have caused a stir in international stock markets, with tech stocks seeing significant movement.',
        source: '#',
        date: '2024-05-21',
    },
    {
        title: 'The Future of Remote Work',
        description: 'A new report analyzes the long-term viability and trends of remote work for large corporations.',
        source: '#',
        date: '2024-05-19',
    },
  ],
};


export default function BeeNewsPage() {
    const router = useRouter();
    const [userSkills, setUserSkills] = React.useState<string[]>([]);
    const [isLoading, setIsLoading] = React.useState(true);

    React.useEffect(() => {
        const savedSkills = localStorage.getItem('user_skills_ids');
        if (savedSkills) {
            setUserSkills(savedSkills.split(','));
        } else {
            // Redirect to skill selection if none are saved
            router.push('/student/skills');
        }
        setIsLoading(false);
    }, [router]);

    if (isLoading) {
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
            </div>
        );
    }

    const relevantNews = userSkills.reduce((acc, skillId) => {
        if (mockNews[skillId]) {
            acc.push({
                skillName: skillsMap[skillId],
                articles: mockNews[skillId],
            });
        }
        return acc;
    }, [] as { skillName: string; articles: any[] }[]);

    return (
        <div className="container mx-auto p-4 md:p-8">
            <div className="mb-8">
                <h1 className="font-headline text-4xl font-bold flex items-center gap-3">
                <Newspaper className="h-10 w-10 text-primary" />
                Bee News
                </h1>
                <p className="text-muted-foreground text-lg mt-2">
                The latest buzz in your fields of interest.
                </p>
            </div>

            {relevantNews.length > 0 ? (
                 <div className="space-y-8">
                    {relevantNews.map(({ skillName, articles }) => (
                        <section key={skillName}>
                            <h2 className="font-headline text-3xl font-bold mb-4">{skillName}</h2>
                            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                                {articles.map((article, index) => (
                                    <Card key={index} className="flex flex-col">
                                        <CardHeader>
                                            <CardTitle className="font-headline text-xl">{article.title}</CardTitle>
                                            <CardDescription>{new Date(article.date).toLocaleDateString()}</CardDescription>
                                        </CardHeader>
                                        <CardContent className="flex-grow">
                                            <p className="text-muted-foreground">{article.description}</p>
                                        </CardContent>
                                        <CardFooter>
                                            <Button variant="outline" asChild>
                                                <a href={article.source} target="_blank" rel="noopener noreferrer">
                                                    <LinkIcon className="mr-2 h-4 w-4"/>
                                                    Read More
                                                </a>
                                            </Button>
                                        </CardFooter>
                                    </Card>
                                ))}
                            </div>
                        </section>
                    ))}
                </div>
            ) : (
                <div className="text-center py-16">
                    <p className="text-muted-foreground">
                        Select your skills to see the latest news.
                    </p>
                    <Button onClick={() => router.push('/student/skills')} className="mt-4">
                        Select Skills
                    </Button>
                </div>
            )}
        </div>
    );
}
