'use client';
import * as React from 'react';
import { useRouter } from 'next/navigation';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
  ArrowUp,
  BookOpen,
} from 'lucide-react';
import { HexagonAvatar } from '@/components/dashboard/student/hexagon-avatar';
import { BeeIcon } from '@/components/icons';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';

function RoamingBees() {
    return (
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <BeeIcon className="w-5 h-5 absolute animate-bee-1" />
            <BeeIcon className="w-4 h-4 absolute animate-bee-2" />
            <BeeIcon className="w-6 h-6 absolute animate-bee-3" />
            <BeeIcon className="w-5 h-5 absolute animate-bee-4" />
            <BeeIcon className="w-3 h-3 absolute animate-bee-5" />
      </div>
    );
}

function GrowPointsCard() {
    const [points, setPoints] = React.useState(1250);
    const [showBee, setShowBee] = React.useState(false);
  
    const handleAddPoints = () => {
      setPoints(points + 50);
      setShowBee(true);
      setTimeout(() => setShowBee(false), 2000);
    };

    return (
        <Card>
            <CardHeader className="pb-2">
            <CardDescription>Grow Points</CardDescription>
            <CardTitle className="text-4xl font-headline flex items-center">
                {points}
                {showBee && (
                    <span className="ml-4 bee-fly-in">
                    <BeeIcon className="w-8 h-8 text-primary" />
                    </span>
                )}
            </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="text-xs text-muted-foreground flex items-center">
                    <ArrowUp className="h-4 w-4 mr-1 text-green-500" />
                    +50 since last week
                </div>
            </CardContent>
            <CardContent>
                 <Button onClick={handleAddPoints} size="sm">Add 50 Points (Demo)</Button>
            </CardContent>
      </Card>
    );
}

function AttendanceCard() {
    return (
        <Card>
            <CardHeader className="pb-2">
                <CardDescription>Attendance</CardDescription>
                <CardTitle className="text-4xl font-headline">95%</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="text-xs text-muted-foreground">38 of 40 classes attended</div>
                <Progress value={95} className="mt-2" />
            </CardContent>
        </Card>
    );
}

function ReportCardPreview() {
    return (
        <Card className="col-span-1 md:col-span-2">
            <CardHeader>
                <CardTitle className="font-headline flex items-center"><BookOpen className="mr-2" /> Report Card Preview</CardTitle>
                <CardDescription>Your latest performance snapshot.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex flex-col items-center p-4 bg-secondary rounded-lg">
                    <p className="text-sm text-muted-foreground">Math</p>
                    <p className="text-2xl font-bold">A-</p>
                </div>
                <div className="flex flex-col items-center p-4 bg-secondary rounded-lg">
                    <p className="text-sm text-muted-foreground">Science</p>
                    <p className="text-2xl font-bold">B+</p>
                </div>
                <div className="flex flex-col items-center p-4 bg-secondary rounded-lg">
                    <p className="text-sm text-muted-foreground">History</p>
                    <p className="text-2xl font-bold">A</p>
                </div>
                <div className="flex flex-col items-center p-4 bg-secondary rounded-lg">
                    <p className="text-sm text-muted-foreground">English</p>
                    <p className="text-2xl font-bold">A-</p>
                </div>
            </CardContent>
             <CardContent>
                <Button>Download Full Report</Button>
            </CardContent>
        </Card>
    );
}

export default function StudentDashboardPage() {
    const router = useRouter();
    const [hasSelectedSkills, setHasSelectedSkills] = React.useState<boolean | null>(null);

    React.useEffect(() => {
        // In a real app, you would fetch this from your backend/database
        const userHasSkills = localStorage.getItem('user_has_selected_skills');
        if (userHasSkills) {
            setHasSelectedSkills(true);
        } else {
            setHasSelectedSkills(false);
            router.push('/student/skills');
        }
    }, [router]);

    if (hasSelectedSkills === null || hasSelectedSkills === false) {
        return (
            <div className="flex h-screen items-center justify-center">
                <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
            </div>
        );
    }
  return (
    <div className="flex flex-col gap-4 relative">
        <RoamingBees />
        <div className="flex items-center gap-4">
            <HexagonAvatar className="h-16 w-16">
            <AvatarImage src="https://picsum.photos/200/200" data-ai-hint="student profile" />
            <AvatarFallback>BB</AvatarFallback>
            </HexagonAvatar>
            <div>
            <h1 className="text-2xl font-bold font-headline">
                Welcome back, Buzzy Bee!
            </h1>
            <p className="text-muted-foreground">
                Let's make today a great day for learning.
            </p>
            </div>
        </div>
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <GrowPointsCard />
            <AttendanceCard />
            <ReportCardPreview />
        </div>
    </div>
  );
}
