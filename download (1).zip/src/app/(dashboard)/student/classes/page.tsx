'use client';
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, Calendar, Clock } from 'lucide-react';

const classes = [
  {
    id: 1,
    name: 'Biology 101',
    teacher: 'Prof. Honeycomb',
    schedule: 'Mon, Wed, Fri',
    time: '9:00 AM - 10:00 AM',
  },
  {
    id: 2,
    name: 'History of Art',
    teacher: 'Dr. Pollen',
    schedule: 'Tue, Thu',
    time: '11:00 AM - 12:30 PM',
  },
  {
    id: 3,
    name: 'Advanced Mathematics',
    teacher: 'Prof. Stinger',
    schedule: 'Mon, Wed',
    time: '1:00 PM - 2:30 PM',
  },
    {
    id: 4,
    name: 'English Literature',
    teacher: 'Ms. Nectar',
    schedule: 'Tue, Thu',
    time: '3:00 PM - 4:00 PM',
  },
];

export default function ClassesPage() {
  return (
    <div className="flex flex-col gap-4">
      <h1 className="text-2xl font-bold font-headline">Your Classes</h1>
      <div className="grid gap-6 md:grid-cols-2">
        {classes.map((course) => (
          <Card key={course.id}>
            <CardHeader>
              <CardTitle className="font-headline flex items-center gap-2">
                <BookOpen className="h-6 w-6 text-primary" />
                {course.name}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm text-muted-foreground">
              <p className="font-semibold text-foreground">{course.teacher}</p>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{course.schedule}</span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4" />
                <span>{course.time}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
