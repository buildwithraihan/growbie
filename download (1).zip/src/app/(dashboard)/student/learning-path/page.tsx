'use client';

import * as React from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { sampleCourses } from '../skills/page';
import { Lightbulb, BookOpen } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function LearningPathPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const skillsParam = searchParams.get('skills');
  const selectedSkillIds = skillsParam ? skillsParam.split(',') : [];

  const recommendedCourses = selectedSkillIds.flatMap(skillId => sampleCourses[skillId] || []);

  const handleStartLesson = (courseName: string) => {
    const slug = courseName.toLowerCase().replace(/\s+/g, '-');
    router.push(`/student/lesson/${slug}?title=${encodeURIComponent(courseName)}`);
  };

  return (
    <div className="container mx-auto p-4 md:p-8">
      <div className="mb-8">
        <h1 className="font-headline text-4xl font-bold flex items-center gap-3">
          <Lightbulb className="h-10 w-10 text-primary" />
          Your Personalized Learning Path
        </h1>
        <p className="text-muted-foreground text-lg mt-2">
          Based on your interests, here are some courses to get you started.
        </p>
      </div>

      {recommendedCourses.length > 0 ? (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {recommendedCourses.map((course, index) => (
            <Card key={index} className="flex flex-col">
              <CardHeader>
                <CardTitle className="font-headline flex items-center gap-2">
                    <BookOpen className="h-6 w-6 text-primary/80"/>
                    {course.name}
                </CardTitle>
                <CardDescription>{course.description}</CardDescription>
              </CardHeader>
              <CardContent className="flex-grow flex flex-col justify-end">
                <Button className="w-full mt-4" onClick={() => handleStartLesson(course.name)}>
                  Start Lesson
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-muted-foreground">
            No skills selected. Please go back and select your skills to see recommended courses.
          </p>
        </div>
      )}
    </div>
  );
}
