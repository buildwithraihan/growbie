'use client';
import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { CalendarCheck, Percent } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

const attendanceHistory = [
  { date: '2024-05-20', subject: 'Biology 101', status: 'Present' },
  { date: '2024-05-17', subject: 'Biology 101', status: 'Present' },
  { date: '2024-05-15', subject: 'Biology 101', status: 'Absent' },
  { date: '2024-05-13', subject: 'Biology 101', status: 'Present' },
  { date: '2024-05-10', subject: 'History of Art', status: 'Present' },
  { date: '2024-05-08', subject: 'History of Art', status: 'Present' },
];

const overallAttendance = {
    'Biology 101': 92,
    'History of Art': 100,
    'Advanced Mathematics': 95,
    'English Literature': 98,
}

export default function AttendancePage() {
  return (
    <div className="flex flex-col gap-8">
      <div>
        <h1 className="text-2xl font-bold font-headline mb-4 flex items-center gap-2">
            <CalendarCheck className="h-6 w-6"/>
            Attendance Overview
        </h1>
        <div className="grid gap-4 md:grid-cols-2">
            {Object.entries(overallAttendance).map(([subject, percentage]) => (
                <Card key={subject}>
                    <CardHeader className='pb-2'>
                        <CardTitle className="text-lg font-headline">{subject}</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="flex items-center justify-between">
                            <span className="text-3xl font-bold">{percentage}%</span>
                            <Percent className="h-6 w-6 text-muted-foreground"/>
                        </div>
                        <Progress value={percentage} className="mt-2" />
                    </CardContent>
                </Card>
            ))}
        </div>
      </div>
      <Card>
        <CardHeader>
          <CardTitle className="font-headline">Attendance History</CardTitle>
          <CardDescription>A log of your attendance records for all classes.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {attendanceHistory.map((record, index) => (
                <TableRow key={index}>
                  <TableCell>{record.date}</TableCell>
                  <TableCell>{record.subject}</TableCell>
                  <TableCell>
                    <Badge
                      variant={record.status === 'Present' ? 'default' : 'destructive'}
                      className={record.status === 'Present' ? 'bg-green-600 hover:bg-green-700' : ''}
                    >
                      {record.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
