
'use client';
import { useSearchParams, useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import React from 'react';

const lessonContent: Record<string, React.ReactNode> = {
    'python-basics': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Introduction to Python</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Python is a high-level, general-purpose programming language. Its design philosophy emphasizes code readability with the use of significant indentation. Python is dynamically-typed and garbage-collected. It supports multiple programming paradigms, including structured (particularly procedural), object-oriented and functional programming. It is a great language for beginners and is widely used in web development, data science, artificial intelligence, and more.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>What is Python and why is it popular?</li>
                    <li>Setting up your Python environment.</li>
                    <li>Variables, data types, and basic operators.</li>
                    <li>Writing and running your first Python script.</li>
                </ul>
                <p>
                    In this lesson, we will explore the basic syntax of Python, learn about variables, data types, and how to write your first simple programs. By the end, you'll have a solid foundation to build upon for more advanced topics. Let's get started!
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/rfscVS0vtbw"
                        title="Python for Beginners - Full Course"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'web-development': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Introduction to Web Development</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Web development is the work involved in developing a website for the Internet or an intranet. Web development can range from developing a simple single static page of plain text to complex web applications, electronic businesses, and social network services.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>HTML: The structure of web pages.</li>
                    <li>CSS: Styling and layout of web pages.</li>
                    <li>JavaScript: Making web pages interactive.</li>
                    <li>The relationship between client-side and server-side development.</li>
                </ul>
                <p>
                   In this lesson, we will cover the fundamental building blocks of the web. You'll learn how HTML, CSS, and JavaScript work together to create the websites you use every day.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/G3e-cpL7ofc"
                        title="Web Development for Beginners - Full Course"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'ai-fundamentals': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: AI Fundamentals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Artificial intelligence (AI) is intelligence demonstrated by machines, as opposed to the natural intelligence displayed by humans and animals. It is a wide-ranging branch of computer science concerned with building smart machines capable of performing tasks that typically require human intelligence.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>What is AI? History and Evolution.</li>
                    <li>Types of AI: Narrow, General, and Superintelligence.</li>
                    <li>Introduction to Machine Learning and Deep Learning.</li>
                    <li>Real-world applications of AI.</li>
                </ul>
                <p>
                  This lesson provides a high-level overview of Artificial Intelligence, demystifying the terminology and exploring its impact on our world.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/2ePf9rue1Ao"
                        title="AI For Beginners - Full Course"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'robotics-fundamentals': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Robotics Fundamentals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Robotics is an interdisciplinary field that integrates computer science and engineering. Robotics involves the design, construction, operation, and use of robots. The goal of robotics is to design machines that can help and assist humans.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>Components of a robot: sensors, actuators, and controllers.</li>
                    <li>Types of robots and their applications.</li>
                    <li>Basic programming for robotics.</li>
                    <li>The future of robotics and automation.</li>
                </ul>
                <p>
                  Dive into the world of robotics! This lesson covers the basic components that make up a robot and explores the different ways they are used in society.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/0y3nnhn3I7I"
                        title="Introduction to Robotics - Full Course"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'mechanical-engineering-concepts': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Mechanical Engineering Concepts</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                   Mechanical engineering is an engineering branch that combines engineering physics and mathematics principles with materials science to design, analyze, manufacture, and maintain mechanical systems. It is one of the oldest and broadest of the engineering branches.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>Statics, dynamics, and thermodynamics.</li>
                    <li>Material science and strength of materials.</li>
                    <li>Introduction to fluid mechanics.</li>
                    <li>Design and manufacturing principles.</li>
                </ul>
                <p>
                  Explore the core principles that govern how physical objects and systems work. This lesson provides a foundational understanding of key mechanical engineering concepts.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/hVo_L_eLgHY"
                        title="Mechanical Engineering: Crash Course Engineering #3"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'digital-storytelling': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Introduction to Digital Storytelling</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Digital storytelling is the practice of using computer-based tools to tell stories. As with traditional storytelling, most digital stories focus on a specific topic and contain a particular point of view. However, they usually contain some mixture of computer-based images, text, recorded audio narration, video clips and/or music.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>The seven elements of digital storytelling.</li>
                    <li>Finding and developing your story.</li>
                    <li>Tools and software for creating digital stories.</li>
                    <li>Sharing your story with the world.</li>
                </ul>
                <p>
                  Learn how to craft compelling narratives in the digital age. This lesson introduces the fundamental concepts of digital storytelling and gives you the tools to start creating your own.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/dKoj54l2gI4"
                        title="The Art of Digital Storytelling"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
    'video-production-essentials': (
        <>
            <CardHeader>
                <CardTitle>Lesson 1: Video Production Essentials</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <p>
                    Video production is the entire process of creating a video. Whether it's a short film, a music video, a commercial, or a YouTube vlog, the process of bringing an idea to life on screen involves several key stages.
                </p>
                <h3 className="font-semibold text-xl">Key Topics</h3>
                <ul className="list-disc pl-5 space-y-2">
                    <li>Pre-production: Planning, scripting, and storyboarding your vision.</li>
                    <li>Production: Camera operation, lighting techniques, and recording clear audio.</li>
                    <li>Post-production: Editing footage, color grading, and adding effects.</li>
                    <li>Exporting and sharing your final video for your audience.</li>
                </ul>
                <p>
                  This lesson will walk you through the three main stages of video production and give you the foundational knowledge to start creating your own professional-looking videos.
                </p>
                <div className="aspect-video rounded-lg overflow-hidden">
                    <iframe
                        className="w-full h-full"
                        src="https://www.youtube.com/embed/g8e4s3d2p9E"
                        title="Video Production for Beginners"
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowFullScreen
                    ></iframe>
                </div>
            </CardContent>
        </>
    ),
}

export default function LessonPage() {
    const router = useRouter();
    const searchParams = useSearchParams();
    const title = searchParams.get('title') || 'Lesson';
    const slug = title.toLowerCase().replace(/\s+/g, '-');

    const goBack = () => {
        router.back();
    };

    const getLessonContent = () => {
        if (lessonContent[slug]) {
            return lessonContent[slug];
        }
        // Default to python content if no specific match
        return lessonContent['python-basics'];
    }

  return (
    <div className="container mx-auto p-4 md:p-8">
        <div className="mb-8">
            <Button variant="ghost" onClick={goBack} className="mb-4">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Learning Path
            </Button>
            <h1 className="font-headline text-4xl font-bold">{title}</h1>
        </div>

        <Card>
            {getLessonContent()}
        </Card>
    </div>
  );
}
