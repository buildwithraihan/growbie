'use client';
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Loader2, PlusCircle, CheckCircle } from 'lucide-react';

const students = [
    { id: '1', name: 'Alex Bee' },
    { id: '2', name: 'Bella Hive' },
    { id: '3', name: 'Charlie Pollen' },
    { id: '4', name: 'Diana Nectar' },
    { id: '5', name: 'Evan Stinger' },
];

const subjects = [
    { id: '1', name: 'Biology 101' },
    { id: '2', name: 'History of Art' },
    { id: '3', name: 'Advanced Mathematics' },
    { id: '4', name: 'English Literature' },
]

export default function EnterMarksPage() {
  const { toast } = useToast();
  const [selectedStudent, setSelectedStudent] = React.useState('');
  const [selectedSubject, setSelectedSubject] = React.useState('');
  const [mark, setMark] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);

  const handleSubmitMarks = async () => {
    if (!selectedStudent || !selectedSubject || !mark) {
        toast({
            variant: 'destructive',
            title: 'Missing Information',
            description: 'Please select a student, a subject, and enter a mark.',
        });
        return;
    }
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsLoading(false);
    toast({
        title: 'Marks Submitted!',
        description: `A grade of ${mark} was recorded for ${students.find(s=>s.id === selectedStudent)?.name} in ${subjects.find(s=>s.id === selectedSubject)?.name}.`,
        className: 'bg-green-600 text-white',
    });

    setSelectedStudent('');
    setSelectedSubject('');
    setMark('');
  };

  return (
    <div className="flex justify-center items-start p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="font-headline flex items-center gap-2"><PlusCircle/> Enter Student Marks</CardTitle>
          <CardDescription>
            Select a student and a subject to enter their latest marks or grade.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                    <label className="font-semibold">Select Student</label>
                    <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                        <SelectTrigger>
                            <SelectValue placeholder="Choose a student..." />
                        </SelectTrigger>
                        <SelectContent>
                            {students.map(student => (
                                <SelectItem key={student.id} value={student.id}>{student.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
                <div className="space-y-2">
                    <label className="font-semibold">Select Subject</label>
                    <Select value={selectedSubject} onValueChange={setSelectedSubject}>
                        <SelectTrigger>
                            <SelectValue placeholder="Choose a subject..." />
                        </SelectTrigger>
                        <SelectContent>
                            {subjects.map(subject => (
                                <SelectItem key={subject.id} value={subject.id}>{subject.name}</SelectItem>
                            ))}
                        </SelectContent>
                    </Select>
                </div>
            </div>
            
            <div className="space-y-2">
                <label className="font-semibold">Enter Mark or Grade</label>
                <Input 
                    value={mark} 
                    onChange={(e) => setMark(e.target.value)} 
                    placeholder="e.g. A+, 95%, etc."
                />
            </div>

          <Button onClick={handleSubmitMarks} disabled={isLoading} size="lg" className="w-full">
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            <CheckCircle className="mr-2 h-4 w-4"/>
            Submit Marks
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
