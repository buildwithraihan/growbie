'use client';
import * as React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Award, Bot, Check, Loader2, Medal, Sparkles, Star } from 'lucide-react';

const students = [
    { id: '1', name: 'Alex Bee' },
    { id: '2', name: 'Bella Hive' },
    { id: '3', name: 'Charlie Pollen' },
    { id: '4', name: 'Diana Nectar' },
    { id: '5', name: 'Evan Stinger' },
];

const badges = [
    { id: '1', name: 'Star Student', icon: Star, description: 'For outstanding performance.' },
    { id: '2', name: 'Perfect Attendance', icon: Check, description: 'For never missing a class.' },
    { id: '3',name: 'Creative Bee', icon: Sparkles, description: 'For exceptional creativity.'},
    { id: '4', name: 'AI Whiz', icon: Bot, description: 'For excelling in AI projects.'},
]

export default function AwardBadgePage() {
  const { toast } = useToast();
  const [selectedStudent, setSelectedStudent] = React.useState('');
  const [selectedBadge, setSelectedBadge] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);

  const handleAwardBadge = async () => {
    if (!selectedStudent || !selectedBadge) {
        toast({
            variant: 'destructive',
            title: 'Missing Information',
            description: 'Please select a student and a badge.',
        });
        return;
    }
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsLoading(false);
    toast({
        title: 'Badge Awarded!',
        description: `${students.find(s=>s.id === selectedStudent)?.name} received the ${badges.find(b=>b.id === selectedBadge)?.name} badge.`,
        className: 'bg-green-600 text-white',
    });

    setSelectedStudent('');
    setSelectedBadge('');
  };

  return (
    <div className="flex justify-center items-start p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle className="font-headline flex items-center gap-2"><Medal/> Award a Badge</CardTitle>
          <CardDescription>
            Recognize your students' hard work and achievements with a special badge.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
            <div className="space-y-2">
                <label className="font-semibold">Select Student</label>
                <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                        <SelectValue placeholder="Choose a student..." />
                    </SelectTrigger>
                    <SelectContent>
                        {students.map(student => (
                            <SelectItem key={student.id} value={student.id}>{student.name}</SelectItem>
                        ))}
                    </SelectContent>
                </Select>
            </div>
            
            <div className="space-y-2">
                <label className="font-semibold">Select Badge</label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {badges.map(badge => {
                        const BadgeIcon = badge.icon;
                        return (
                            <Card 
                                key={badge.id}
                                className={`cursor-pointer transition-all ${selectedBadge === badge.id ? 'ring-2 ring-primary' : ''}`}
                                onClick={() => setSelectedBadge(badge.id)}
                            >
                                <CardContent className="flex flex-col items-center justify-center p-4 text-center">
                                    <BadgeIcon className="w-10 h-10 text-primary mb-2"/>
                                    <p className="font-medium text-sm">{badge.name}</p>
                                </CardContent>
                            </Card>
                        )
                    })}
                </div>
            </div>

          <Button onClick={handleAwardBadge} disabled={isLoading} size="lg" className="w-full">
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            <Award className="mr-2 h-4 w-4"/>
            Award Badge
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
