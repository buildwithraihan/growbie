'use client';
import Link from 'next/link';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Medal, MoreHorizontal, PlusCircle, QrCode } from 'lucide-react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Rectangle,
  ResponsiveContainer,
  XAxis,
  YAxis,
} from 'recharts';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from '@/components/ui/chart';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const attendanceData = [
  { date: 'Mon', present: 95, absent: 5 },
  { date: 'Tue', present: 98, absent: 2 },
  { date: 'Wed', present: 92, absent: 8 },
  { date: 'Thu', present: 100, absent: 0 },
  { date: 'Fri', present: 96, absent: 4 },
];

const students = [
    { id: 1, name: 'Alex Bee', avatar: '101', attendance: '98%', grade: 'A' },
    { id: 2, name: 'Bella Hive', avatar: '102', attendance: '92%', grade: 'B+' },
    { id: 3, name: 'Charlie Pollen', avatar: '103', attendance: '100%', grade: 'A-' },
    { id: 4, name: 'Diana Nectar', avatar: '104', attendance: '88%', grade: 'C+' },
    { id: 5, name: 'Evan Stinger', avatar: '105', attendance: '95%', grade: 'B' },
]

export default function TeacherDashboard() {
  return (
    <div className="grid auto-rows-max items-start gap-4 md:gap-8 lg:col-span-2">
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Total Students</CardDescription>
            <CardTitle className="text-4xl font-headline">24</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-xs text-muted-foreground">
              in your "Biology 101" class
            </div>
          </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="font-headline text-lg">Live Attendance</CardTitle>
                <QrCode className="h-6 w-6 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Start a new session to take attendance.</p>
                <Button asChild className="w-full">
                    <Link href="/live-session">Start New Session</Link>
                </Button>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="font-headline text-lg">Award Badges</CardTitle>
                <Medal className="h-6 w-6 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Recognize student achievements.</p>
                <Button asChild variant="secondary" className="w-full">
                    <Link href="/teacher/award-badge">Award a Badge</Link>
                </Button>
            </CardContent>
        </Card>
        <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="font-headline text-lg">Enter Marks</CardTitle>
                <PlusCircle className="h-6 w-6 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground mb-4">Update grades for the latest assignment.</p>
                <Button asChild variant="secondary" className="w-full">
                    <Link href="/teacher/enter-marks">Enter New Marks</Link>
                </Button>
            </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-7">
        <Card className="col-span-4">
          <CardHeader>
            <CardTitle className="font-headline">Weekly Attendance</CardTitle>
            <CardDescription>
              Attendance trends for "Biology 101" this week.
            </CardDescription>
          </CardHeader>
          <CardContent className="pl-2">
            <ChartContainer
              config={{
                present: { label: 'Present', color: 'hsl(var(--primary))' },
                absent: { label: 'Absent', color: 'hsl(var(--muted))' },
              }}
              className="h-[300px] w-full"
            >
              <BarChart data={attendanceData} accessibilityLayer>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="date"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={false}
                />
                <YAxis
                    tickFormatter={(value) => `${value}%`}
                />
                <ChartTooltip
                  content={<ChartTooltipContent />}
                  cursor={false}
                />
                <Bar
                  dataKey="present"
                  stackId="a"
                  fill="var(--color-present)"
                  radius={[4, 4, 0, 0]}
                />
                <Bar
                  dataKey="absent"
                  stackId="a"
                  fill="var(--color-absent)"
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <Card className="col-span-4 lg:col-span-3">
          <CardHeader>
            <CardTitle className="font-headline">Student Roster</CardTitle>
            <CardDescription>
              Overview of students in "Biology 101".
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead className="text-center">Attendance</TableHead>
                  <TableHead className="text-center">Grade</TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar className="hidden h-9 w-9 sm:flex">
                          <AvatarImage src={`https://picsum.photos/100/${student.avatar}`} data-ai-hint="student avatar" alt="Avatar" />
                          <AvatarFallback>
                            {student.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        <div className="font-medium">{student.name}</div>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                        {student.attendance}
                    </TableCell>
                    <TableCell className="text-center">
                        <Badge variant={student.grade.startsWith('A') ? 'default' : 'secondary'}>
                            {student.grade}
                        </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button aria-haspopup="true" size="icon" variant="ghost">
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuLabel>Actions</DropdownMenuLabel>
                          <DropdownMenuItem>View Profile</DropdownMenuItem>
                          <DropdownMenuItem>Send Message</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
