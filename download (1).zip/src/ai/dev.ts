import { config } from 'dotenv';
config();

import '@/ai/flows/anomalous-join-detection.ts';
import '@/ai/flows/face-scanner-attendance.ts';
