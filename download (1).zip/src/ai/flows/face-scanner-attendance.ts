'use server';

/**
 * @fileOverview An AI agent to identify students from a face scan for attendance.
 *
 * - faceScannerAttendance - A function that handles the face scanning process.
 * - FaceScannerAttendanceInput - The input type for the faceScannerAttendance function.
 * - FaceScannerAttendanceOutput - The return type for the faceScannerAttendance function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const FaceScannerAttendanceInputSchema = z.object({
  photoDataUri: z
    .string()
    .describe(
      "A photo containing faces of students, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
  knownStudentNames: z
    .array(z.string())
    .describe('An array of known student names in the class.'),
});
export type FaceScannerAttendanceInput = z.infer<
  typeof FaceScannerAttendanceInputSchema
>;

const FaceScannerAttendanceOutputSchema = z.object({
  identifiedStudents: z
    .array(z.string())
    .describe('An array of student names identified in the photo.'),
});
export type FaceScannerAttendanceOutput = z.infer<
  typeof FaceScannerAttendanceOutputSchema
>;

export async function faceScannerAttendance(
  input: FaceScannerAttendanceInput
): Promise<FaceScannerAttendanceOutput> {
  return faceScannerAttendanceFlow(input);
}

const prompt = ai.definePrompt({
  name: 'faceScannerAttendancePrompt',
  input: {schema: FaceScannerAttendanceInputSchema},
  output: {schema: FaceScannerAttendanceOutputSchema},
  prompt: `You are an AI assistant that identifies students in a classroom photo.

  Given a photo and a list of known student names, identify which students are present in the photo.

  Photo: {{media url=photoDataUri}}
  Known Students: {{knownStudentNames}}

  Return a list of the names of the identified students.
  If there are no students present in the photo, return an empty list.
  Do not return any students that are not in the list of known students.
  `,
});

const faceScannerAttendanceFlow = ai.defineFlow(
  {
    name: 'faceScannerAttendanceFlow',
    inputSchema: FaceScannerAttendanceInputSchema,
    outputSchema: FaceScannerAttendanceOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
