'use server';

/**
 * @fileOverview Detects anomalous join attempts based on IP address and location history.
 *
 * - detectAnomalousJoin - A function that detects potentially fraudulent attendance recordings.
 * - AnomalousJoinDetectionInput - The input type for the detectAnomalousJoin function.
 * - AnomalousJoinDetectionOutput - The return type for the detectAnomalousJoin function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnomalousJoinDetectionInputSchema = z.object({
  studentId: z.string().describe('The unique identifier for the student.'),
  sessionId: z.string().describe('The unique identifier for the attendance session.'),
  ipAddress: z.string().describe('The IP address of the student at the time of joining.'),
  latitude: z.number().describe('The latitude of the student at the time of joining.'),
  longitude: z.number().describe('The longitude of the student at the time of joining.'),
  recentIpAddresses: z
    .array(z.string())
    .describe('A list of recently used IP addresses by the student.'),
  recentLocations: z
    .array(z.object({latitude: z.number(), longitude: z.number()}))
    .describe('A list of recent locations of the student.'),
});
export type AnomalousJoinDetectionInput = z.infer<
  typeof AnomalousJoinDetectionInputSchema
>;

const AnomalousJoinDetectionOutputSchema = z.object({
  isAnomalous: z
    .boolean()
    .describe(
      'Whether the join attempt is considered anomalous based on IP and location history.'
    ),
  reason: z
    .string()
    .describe(
      'The reason for flagging the join attempt as anomalous, if applicable.'
    ),
});
export type AnomalousJoinDetectionOutput = z.infer<
  typeof AnomalousJoinDetectionOutputSchema
>;

export async function detectAnomalousJoin(
  input: AnomalousJoinDetectionInput
): Promise<AnomalousJoinDetectionOutput> {
  return anomalousJoinDetectionFlow(input);
}

const prompt = ai.definePrompt({
  name: 'anomalousJoinDetectionPrompt',
  input: {schema: AnomalousJoinDetectionInputSchema},
  output: {schema: AnomalousJoinDetectionOutputSchema},
  prompt: `You are an expert system for detecting fraudulent attendance recordings.

You are provided with the student's ID, the session ID, their current IP address and location, and a history of their recent IP addresses and locations.

Analyze this information to determine if the current join attempt is anomalous. Consider factors such as:

- Significant deviations from usual IP addresses or locations.
- Geographically implausible transitions between recent locations and the current location.
- Use of VPNs or proxy servers (if detectable from the IP address).

Based on your analysis, determine whether the join attempt is anomalous and provide a reason for your determination.

Student ID: {{{studentId}}}
Session ID: {{{sessionId}}}
Current IP Address: {{{ipAddress}}}
Current Location: Latitude {{{latitude}}}, Longitude {{{longitude}}}
Recent IP Addresses: {{#each recentIpAddresses}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
Recent Locations: {{#each recentLocations}}Latitude {{{this.latitude}}}, Longitude {{{this.longitude}}}{{#unless @last}}, {{/unless}}{{/each}}

Output your reasoning, and whether the join is anomalous in JSON format:
`,
});

const anomalousJoinDetectionFlow = ai.defineFlow(
  {
    name: 'anomalousJoinDetectionFlow',
    inputSchema: AnomalousJoinDetectionInputSchema,
    outputSchema: AnomalousJoinDetectionOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
