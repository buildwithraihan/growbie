'use server';

import {
  faceScannerAttendance,
  type FaceScannerAttendanceInput,
} from '@/ai/flows/face-scanner-attendance';
import {
  detectAnomalousJoin,
  type AnomalousJoinDetectionInput,
} from '@/ai/flows/anomalous-join-detection';

export async function identifyStudentsFromPhoto(
  input: FaceScannerAttendanceInput
) {
  return await faceScannerAttendance(input);
}

export async function checkAnomalousJoin(input: AnomalousJoinDetectionInput) {
  return await detectAnomalousJoin(input);
}

export async function saveUserSkills(skills: string[]) {
    // In a real app, this would save to Firestore.
    // For this demo, we'll just log it to the console.
    console.log('Saving user skills:', skills);
    // Simulate a network delay
    await new Promise(resolve => setTimeout(resolve, 500));
    // Simulate a successful save
    return { success: true };
}
